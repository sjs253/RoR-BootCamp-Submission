NAME- Shreyansh Shrivastava
BRANCH- CS 2nd year

Changes

1. bootstrap datepicker is included.for this a helper jquery is made in the main.js file in app/assets/javascripts
2. bootstrap colorpicker is included. again jquery is used in a separate file color.js in app/assets/javascripts
3. bootstrap buttons are used for the various links
4. The basic formatting of index was not visible because one bootstrap-gem was excluded as it was causing problem
5. Basic bootstrap formatting buttons are used for various links.

ERRORS

1. The finish column in the database is not compatible with the date-format provided by the datepicker hence in index.html.erb the deadline column is somewhat wrong
2. The third task was also tried to include by the code

	<% if todo_lists.finish > #some mwthod to get today's date#%>
		<td> PENDING </td>
	<% else %>
		<td> CHILL </td> 
	<% end %>
but the method was not working somehow. the link used for this method is https://api.rubyonrails.org/v5.1/classes/Date.html

Thanks 
