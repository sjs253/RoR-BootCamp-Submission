$(document).ready(function(){
    $('.color').colorpicker();
});
