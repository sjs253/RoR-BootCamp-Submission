class AddCheckboxColumnToTodoList < ActiveRecord::Migration[5.2]
  def change
    add_column :todo_lists, :checkbox, :boolean
  end
end
