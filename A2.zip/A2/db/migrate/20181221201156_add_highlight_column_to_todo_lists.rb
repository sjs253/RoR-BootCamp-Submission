class AddHighlightColumnToTodoLists < ActiveRecord::Migration[5.2]
  def change
    add_column :todo_lists, :highlight, :text
  end
end
