class AddColumnDeadlineToTodoLists < ActiveRecord::Migration[5.2]
  def change
    add_column :todo_lists, :finish, :datetime
  end
end
